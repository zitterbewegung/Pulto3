import Foundation
import simd
import RealityKit

enum ImportedKind: String, Codable {
    case usdz
    case pointCloud
}

struct PointCloudSettings: Codable {
    var maxPoints: Int
    var pointRadius: Float
}

struct TransformCodable: Codable {
    var t: [Float]    // translation xyz
    var r: [Float]    // quaternion (x,y,z,w)
    var s: [Float]    // scale xyz

    init(_ transform: Transform) {
        t = [transform.translation.x, transform.translation.y, transform.translation.z]
        r = [transform.rotation.imag.x, transform.rotation.imag.y, transform.rotation.imag.z, transform.rotation.real]
        s = [transform.scale.x, transform.scale.y, transform.scale.z]
    }

    func asTransform() -> Transform {
        let T = SIMD3<Float>(t[0], t[1], t[2])
        let q = simd_quatf(ix: r[0], iy: r[1], iz: r[2], r: r[3])
        let S = SIMD3<Float>(s[0], s[1], s[2])
        return Transform(scale: S, rotation: q, translation: T)
    }
}

struct EntityRecord: Codable, Identifiable {
    var id: UUID
    var kind: ImportedKind
    var filename: String
    /// local path relative to App Support directory
    var localRelativePath: String
    var transform: TransformCodable
    var point: PointCloudSettings?
}

struct AppState: Codable {
    var items: [EntityRecord] = []
}

enum PersistenceManager {
    static var appSupportURL: URL = {
        let fm = FileManager.default
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let url = base.appendingPathComponent("Pulto", isDirectory: true)
        if !fm.fileExists(atPath: url.path) {
            try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        }
        return url
    }()

    static var stateURL: URL {
        appSupportURL.appendingPathComponent("state.json")
    }

    static func copyIntoAppSupport(original url: URL, id: UUID) throws -> URL {
        let ext = url.pathExtension
        let dest = appSupportURL.appendingPathComponent("\(id.uuidString).\(ext)")
        if FileManager.default.fileExists(atPath: dest.path) {
            try? FileManager.default.removeItem(at: dest)
        }
        try FileManager.default.copyItem(at: url, to: dest)
        return dest
    }

    static func deleteLocalFile(relative path: String) {
        let full = appSupportURL.appendingPathComponent(path)
        try? FileManager.default.removeItem(at: full)
    }

    static func save(_ state: AppState) {
        do {
            let data = try JSONEncoder().encode(state)
            try data.write(to: stateURL, options: .atomic)
        } catch {
            print("Persistence save error: \(error)")
        }
    }

    static func load() -> AppState {
        guard let data = try? Data(contentsOf: stateURL) else { return AppState() }
        do {
            return try JSONDecoder().decode(AppState.self, from: data)
        } catch {
            print("Persistence load error: \(error)")
            return AppState()
        }
    }
}
