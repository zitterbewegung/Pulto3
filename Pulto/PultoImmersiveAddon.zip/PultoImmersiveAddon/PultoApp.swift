import SwiftUI

@main
struct PultoApp: App {
    @StateObject private var sceneModel = SceneModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(sceneModel)
        }

        ImmersiveSpace(id: "PultoImmersiveSpace") {
            ImmersiveSpaceView()
                .environmentObject(sceneModel)
        }
        .immersionStyle(selection: .constant(.full), in: .full)
    }
}
