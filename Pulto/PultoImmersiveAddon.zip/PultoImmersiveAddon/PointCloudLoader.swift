import Foundation
import simd

struct PointCloudData {
    var points: [SIMD3<Float>]
    var colors: [SIMD3<Float>]? // 0..1 per channel
}

enum PointCloudLoaderError: Error {
    case invalidFormat(String)
    case notAscii
}

enum PointCloudLoader {

    static func loadXYZ(url: URL) throws -> PointCloudData {
        let text = try String(contentsOf: url)
        var points: [SIMD3<Float>] = []
        var colors: [SIMD3<Float>] = []

        for line in text.split(whereSeparator: \.isNewline) {
            let parts = line.split(whereSeparator: { $0 == " " || $0 == "\t" })
            guard parts.count >= 3 else { continue }
            guard let x = Float(parts[0]),
                  let y = Float(parts[1]),
                  let z = Float(parts[2]) else { continue }
            points.append(.init(x, y, z))

            if parts.count >= 6,
               let r = Float(parts[3]),
               let g = Float(parts[4]),
               let b = Float(parts[5]) {
                let rr = r > 1 ? r / 255.0 : r
                let gg = g > 1 ? g / 255.0 : g
                let bb = b > 1 ? b / 255.0 : b
                colors.append(.init(rr, gg, bb))
            }
        }
        return PointCloudData(points: points, colors: colors.isEmpty ? nil : colors)
    }

    static func loadPLY_ASCII(url: URL) throws -> PointCloudData {
        let text = try String(contentsOf: url, encoding: .utf8)
        let lines = text.split(whereSeparator: \.isNewline).map(String.init)
        guard let endHeaderIndex = lines.firstIndex(of: "end_header") else {
            throw PointCloudLoaderError.invalidFormat("Missing end_header")
        }

        var vertexCount = 0
        var hasRGB = false
        var propOrder: [String] = []

        for l in lines.prefix(endHeaderIndex) {
            if l.hasPrefix("format ") && !l.contains("ascii") {
                throw PointCloudLoaderError.notAscii
            }
            if l.hasPrefix("element vertex") {
                let parts = l.split(separator: " ")
                if let last = parts.last, let n = Int(last) { vertexCount = n }
            }
            if l.hasPrefix("property ") {
                let parts = l.split(separator: " ")
                if parts.count >= 3 { propOrder.append(String(parts.last!)) }
            }
        }
        hasRGB = Set(propOrder).isSuperset(of: ["red","green","blue"])

        let start = endHeaderIndex + 1
        let verts = lines.dropFirst(start).prefix(vertexCount)

        var points: [SIMD3<Float>] = []
        var colors: [SIMD3<Float>] = []

        for v in verts {
            let parts = v.split(whereSeparator: { $0 == " " || $0 == "\t" }).map(String.init)
            guard let ix = propOrder.firstIndex(of: "x"),
                  let iy = propOrder.firstIndex(of: "y"),
                  let iz = propOrder.firstIndex(of: "z") else { continue }
            guard
                let x = Float(parts[safe: ix] ?? ""),
                let y = Float(parts[safe: iy] ?? ""),
                let z = Float(parts[safe: iz] ?? "")
            else { continue }
            points.append(.init(x, y, z))

            if hasRGB,
               let ir = propOrder.firstIndex(of: "red"),
               let ig = propOrder.firstIndex(of: "green"),
               let ib = propOrder.firstIndex(of: "blue"),
               let r = Float(parts[safe: ir] ?? ""),
               let g = Float(parts[safe: ig] ?? ""),
               let b = Float(parts[safe: ib] ?? "") {
                let rr = r > 1 ? r / 255.0 : r
                let gg = g > 1 ? g / 255.0 : g
                let bb = b > 1 ? b / 255.0 : b
                colors.append(.init(rr, gg, bb))
            }
        }
        return PointCloudData(points: points, colors: colors.isEmpty ? nil : colors)
    }

    static func loadPCD_ASCII(url: URL) throws -> PointCloudData {
        let text = try String(contentsOf: url, encoding: .utf8)
        let lines = text.split(whereSeparator: \.isNewline).map(String.init)
        guard let dataIndex = lines.firstIndex(where: { $0.uppercased().hasPrefix("DATA ") }) else {
            throw PointCloudLoaderError.invalidFormat("Missing DATA line")
        }
        let header = lines.prefix(dataIndex)
        let body = lines.suffix(from: dataIndex + 1)

        guard header.contains(where: { $0.uppercased().trimmingCharacters(in: .whitespaces) == "DATA ASCII" }) else {
            throw PointCloudLoaderError.notAscii
        }

        var fields: [String] = []
        for h in header where h.uppercased().hasPrefix("FIELDS ") {
            fields = h.split(separator: " ").dropFirst().map { String($0).lowercased() }
        }
        guard fields.contains("x"), fields.contains("y"), fields.contains("z") else {
            throw PointCloudLoaderError.invalidFormat("x/y/z fields required")
        }

        var points: [SIMD3<Float>] = []
        var colors: [SIMD3<Float>] = []

        for line in body {
            let parts = line.split(whereSeparator: { $0 == " " || $0 == "\t" }).map(String.init)
            func f(_ name: String) -> Float? {
                guard let idx = fields.firstIndex(of: name), idx < parts.count else { return nil }
                return Float(parts[idx])
            }

            guard let x = f("x"), let y = f("y"), let z = f("z") else { continue }
            points.append(.init(x, y, z))

            if fields.contains("rgb") {
                if let rgbF = f("rgb") {
                    let u = UInt32(bitPattern: Int32(bitPattern: unsafeBitCast(rgbF, to: UInt32.self)))
                    let r = Float((u >> 16) & 0xFF) / 255.0
                    let g = Float((u >> 8) & 0xFF) / 255.0
                    let b = Float(u & 0xFF) / 255.0
                    colors.append(.init(r,g,b))
                } else if let r = f("r"), let g = f("g"), let b = f("b") {
                    let rr = r > 1 ? r/255.0 : r
                    let gg = g > 1 ? g/255.0 : g
                    let bb = b > 1 ? b/255.0 : b
                    colors.append(.init(rr,gg,bb))
                }
            } else if let r = f("r"), let g = f("g"), let b = f("b") {
                let rr = r > 1 ? r/255.0 : r
                let gg = g > 1 ? g/255.0 : g
                let bb = b > 1 ? b/255.0 : b
                colors.append(.init(rr,gg,bb))
            }
        }

        return PointCloudData(points: points, colors: colors.isEmpty ? nil : colors)
    }
}

fileprivate extension Array {
    subscript(safe i: Int) -> Element? { (0..<count).contains(i) ? self[i] : nil }
}
