import SwiftUI
import RealityKit

struct ImmersiveSpaceView: View {
    @EnvironmentObject var sceneModel: SceneModel

    @State private var rootAnchor: AnchorEntity?
    @State private var selectionEntity: Entity?
    @State private var selectionID: UUID?

    @State private var uiPointRadius: Float = 0.006
    @State private var uiMaxPoints: Double = 20_000

    var body: some View {
        RealityView { content, attachments in
            if rootAnchor == nil {
                let anchor = AnchorEntity(.world)
                rootAnchor = anchor
                content.add(anchor)
            }
            if let hud = attachments.entity(for: "hud") {
                rootAnchor?.addChild(hud)
                hud.position = .init(0, 1.2, -1.2)
            }
            if let panel = attachments.entity(for: "panel") {
                rootAnchor?.addChild(panel)
                panel.position = .init(0.5, 1.0, -1.0)
            }
        } attachments: {
            Attachment(id: "hud") {
                VStack(spacing: 8) {
                    Text("Pulto Immersive")
                        .font(.title2.weight(.semibold))
                    Text("Tap select • Drag move • Pinch scale • Rotate Y")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                .padding(12)
                .glassBackgroundEffect()
            }

            Attachment(id: "panel") {
                ControlPanel(
                    selectionID: $selectionID,
                    uiPointRadius: $uiPointRadius,
                    uiMaxPoints: $uiMaxPoints,
                    onReset: { resetSelectedTransform() },
                    onDelete: { deleteSelected() },
                    onSaveLayout: { sceneModel.persistNow() },
                    onApplyPointSettings: { applyPointSettings() }
                )
                .environmentObject(sceneModel)
                .frame(width: 420)
                .padding(12)
                .glassBackgroundEffect()
            }
        }
        .task {
            if let anchor = rootAnchor {
                await sceneModel.restore(in: anchor)
            }
        }
        .onChange(of: sceneModel.restoreAllRequested) { _, new in
            if new, let anchor = rootAnchor {
                Task { await sceneModel.restore(in: anchor) }
                sceneModel.restoreAllRequested = false
            }
        }
        .onChange(of: selectionEntity) { _, newValue in
            if let id = newValue?.persistentID ?? selectionID,
               let rec = sceneModel.record(for: id) {
                selectionID = id
                if let p = rec.point {
                    uiPointRadius = p.pointRadius
                    uiMaxPoints = Double(p.maxPoints)
                }
            }
        }
        .gesture(
            TapGesture().targetedToAnyEntity().onEnded { value in
                let target = ascendToPersistedEntity(value.entity)
                selectionEntity = target
                selectionID = target?.persistentID
            }
        )
        .gesture(
            DragGesture().targetedToAnyEntity()
                .onChanged { value in
                    let entity = ascendToPersistedEntity(value.entity) ?? value.entity
                    var t = entity.transform
                    let dx = Float(value.translation.width) * 0.002
                    let dz = Float(value.translation.height) * 0.002
                    t.translation += SIMD3<Float>(dx, 0, dz)
                    entity.transform = t
                }
                .onEnded { value in
                    let entity = ascendToPersistedEntity(value.entity) ?? value.entity
                    sceneModel.updateTransform(for: entity)
                    sceneModel.persistNow()
                }
        )
        .gesture(
            MagnifyGesture().targetedToAnyEntity()
                .onChanged { value in
                    let entity = ascendToPersistedEntity(value.entity) ?? value.entity
                    let s = Float(value.magnification)
                    var t = entity.transform
                    t.scale *= SIMD3<Float>(repeating: s)
                    entity.transform = t
                }
                .onEnded { value in
                    let entity = ascendToPersistedEntity(value.entity) ?? value.entity
                    sceneModel.updateTransform(for: entity)
                    sceneModel.persistNow()
                }
        )
        .gesture(
            RotateGesture().targetedToAnyEntity()
                .onChanged { value in
                    let entity = ascendToPersistedEntity(value.entity) ?? value.entity
                    let angle = Float(value.rotation.radians)
                    entity.transform.rotation *= simd_quatf(angle: angle, axis: SIMD3<Float>(0,1,0))
                }
                .onEnded { value in
                    let entity = ascendToPersistedEntity(value.entity) ?? value.entity
                    sceneModel.updateTransform(for: entity)
                    sceneModel.persistNow()
                }
        )
        .onChange(of: sceneModel.pendingImports) { _, _ in
            Task { await handleNextImport() }
        }
        .task {
            await handleNextImport()
        }
    }

    private func ascendToPersistedEntity(_ e: Entity) -> Entity? {
        var cur: Entity? = e
        while let node = cur {
            if node.persistentID != nil { return node }
            cur = node.parent
        }
        return nil
    }

    @MainActor
    private func handleNextImport() async {
        guard let url = sceneModel.popNextImport() else { return }
        guard let anchor = rootAnchor else { return }

        let ext = url.pathExtension.lowercased()
        do {
            let id = UUID()
            let local = try PersistenceManager.copyIntoAppSupport(original: url, id: id)
            let rel = local.lastPathComponent

            switch ext {
            case "usdz":
                let entity = try await Entity.load(contentsOf: local)
                entity.position = .init(0, 1.1, -1.2)
                entity.generateCollisionShapes(recursive: true)
                entity.components.set(PersistentIDComponent(id: id))
                anchor.addChild(entity)
                sceneModel.entityByID[id] = entity
                let rec = EntityRecord(
                    id: id,
                    kind: .usdz,
                    filename: url.lastPathComponent,
                    localRelativePath: rel,
                    transform: TransformCodable(entity.transform),
                    point: nil
                )
                sceneModel.upsert(record: rec, persist: true)
                selectionEntity = entity
                selectionID = id

            case "ply", "pcd", "xyz":
                let data = try sceneModel.loadRawPointCloud(from: local)
                sceneModel.rawPointClouds[id] = data
                let entity = try await PointCloudFactory.makePointCloudEntity(
                    points: data.points, colors: data.colors,
                    maxPoints: 20_000, pointRadius: 0.006
                )
                entity.position = .init(0, 1.1, -1.2)
                entity.generateCollisionShapes(recursive: true)
                entity.components.set(PersistentIDComponent(id: id))
                anchor.addChild(entity)
                sceneModel.entityByID[id] = entity
                let rec = EntityRecord(
                    id: id,
                    kind: .pointCloud,
                    filename: url.lastPathComponent,
                    localRelativePath: rel,
                    transform: TransformCodable(entity.transform),
                    point: PointCloudSettings(maxPoints: 20_000, pointRadius: 0.006)
                )
                sceneModel.upsert(record: rec, persist: true)
                selectionEntity = entity
                selectionID = id

            default:
                throw NSError(domain: "Pulto", code: -2,
                              userInfo: [NSLocalizedDescriptionKey: "Unsupported file type: .\(ext)"])
            }
        } catch {
            sceneModel.lastError = error.localizedDescription
        }
        await handleNextImport()
    }

    private func resetSelectedTransform() {
        guard let id = selectionID, let entity = sceneModel.entityByID[id] else { return }
        entity.transform = Transform(scale: .one, rotation: .init(angle: 0, axis: .init(0,1,0)), translation: .zero)
        sceneModel.updateTransform(for: entity)
        sceneModel.persistNow()
    }

    private func deleteSelected() {
        guard let id = selectionID else { return }
        sceneModel.removeRecordAndResources(id: id)
        selectionEntity = nil
        selectionID = nil
    }

    private func applyPointSettings() {
        guard let id = selectionID,
              let rec = sceneModel.record(for: id),
              rec.kind == .pointCloud,
              let anchor = rootAnchor
        else { return }

        let old = rec.point ?? PointCloudSettings(maxPoints: 20_000, pointRadius: 0.006)
        let newMax = max(1_000, Int(uiMaxPoints))

        if abs(old.maxPoints - newMax) >= 1 {
            Task {
                await sceneModel.rebuildPointCloud(
                    id: id,
                    maxPoints: newMax,
                    pointRadius: uiPointRadius,
                    anchor: anchor
                )
            }
        } else if abs(old.pointRadius - uiPointRadius) > .ulpOfOne {
            sceneModel.applyPointRadius(id: id, newRadius: uiPointRadius)
        }
    }
}

private struct ControlPanel: View {
    @EnvironmentObject var sceneModel: SceneModel

    @Binding var selectionID: UUID?
    @Binding var uiPointRadius: Float
    @Binding var uiMaxPoints: Double

    var onReset: () -> Void
    var onDelete: () -> Void
    var onSaveLayout: () -> Void
    var onApplyPointSettings: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Controls").font(.title3.bold())
                Spacer()
                Button("Save Layout", action: onSaveLayout)
            }

            if let id = selectionID, let rec = sceneModel.record(for: id) {
                LabeledContent("Selected") {
                    Text(rec.filename).lineLimit(1).truncationMode(.middle)
                }
                LabeledContent("Type") {
                    Text(rec.kind == .usdz ? "USDZ" : "Point Cloud")
                }

                if rec.kind == .pointCloud {
                    Divider()
                    Text("Point Cloud").font(.headline)
                    HStack {
                        Text("Point Size")
                        Slider(value: Binding(get: {
                            Double(uiPointRadius)
                        }, set: { uiPointRadius = Float($0) }), in: 0.001...0.03)
                        Text(String(format: "%.3f", uiPointRadius))
                            .monospacedDigit()
                            .frame(width: 60, alignment: .trailing)
                    }
                    HStack {
                        Text("Max Points")
                        Slider(value: $uiMaxPoints, in: 1_000...100_000, step: 1_000)
                        Text("\(Int(uiMaxPoints))").monospacedDigit()
                            .frame(width: 80, alignment: .trailing)
                    }
                    HStack {
                        Button("Apply", action: onApplyPointSettings)
                            .buttonStyle(.borderedProminent)
                        Spacer()
                    }
                }

                Divider()
                HStack {
                    Button("Reset Transform", action: onReset)
                    Spacer()
                    Button(role: .destructive, action: onDelete) {
                        Label("Delete", systemImage: "trash")
                    }
                }
            } else {
                Text("No selection").foregroundStyle(.secondary)
            }
        }
    }
}
