import Foundation
import RealityKit

enum USDZLoader {
    static func loadUSDZ(from url: URL) async throws -> Entity {
        if #available(visionOS 1.0, *) {
            return try await Entity.load(contentsOf: url)
        } else {
            return try Entity.load(contentsOf: url)
        }
    }
}
