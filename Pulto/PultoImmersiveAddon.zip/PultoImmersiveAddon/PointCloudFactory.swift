import RealityKit
import simd

enum PointCloudFactoryError: Error {
    case empty
}

enum PointCloudFactory {

    static func makePointCloudEntity(
        points: [SIMD3<Float>],
        colors: [SIMD3<Float>]? = nil,
        maxPoints: Int = 20_000,
        pointRadius: Float = 0.006
    ) async throws -> Entity {

        guard !points.isEmpty else { throw PointCloudFactoryError.empty }

        let stride = max(1, points.count / max(1, maxPoints))
        var pts: [SIMD3<Float>] = []
        var cols: [SIMD3<Float>]? = colors != nil ? [] : nil
        pts.reserveCapacity(min(points.count, maxPoints))

        for i in Swift.stride(from: 0, to: points.count, by: stride) {
            pts.append(points[i])
            if var cc = cols, let csrc = colors, i < csrc.count {
                cc.append(csrc[i])
                cols = cc
            }
            if pts.count >= maxPoints { break }
        }

        let parent = Entity()
        parent.name = "PointCloud"

        let sphere = MeshResource.generateSphere(radius: pointRadius, segments: 6)
        let defaultMaterial = SimpleMaterial(color: .white, isMetallic: false)

        for (idx, p) in pts.enumerated() {
            let me = ModelEntity(mesh: sphere, materials: [defaultMaterial])
            me.position = p
            if let cols = cols, idx < cols.count {
                let c = cols[idx]
                me.model?.materials = [
                    SimpleMaterial(
                        color: .init(red: CGFloat(c.x), green: CGFloat(c.y), blue: CGFloat(c.z), alpha: 1),
                        isMetallic: false
                    )
                ]
            }
            parent.addChild(me)
        }

        if !pts.isEmpty {
            let mean = pts.reduce(SIMD3<Float>(repeating: 0), +) / Float(pts.count)
            for ch in parent.children {
                ch.position -= mean
            }
        }

        return parent
    }
}
