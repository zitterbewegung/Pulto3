import RealityKit

/// Attach this to any entity we want to persist/track.
struct PersistentIDComponent: Component {
    var id: UUID
}
