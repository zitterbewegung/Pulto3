import Foundation
import SwiftUI
import RealityKit
import simd

@MainActor
final class SceneModel: ObservableObject {

    // MARK: - Public state / errors
    @Published var lastError: String?
    @Published var pendingImports: [URL] = []
    @Published var restoreAllRequested: Bool = false

    // MARK: - Persistence model
    private(set) var state: AppState = PersistenceManager.load()

    // Mappings: runtime entities & raw clouds, by id
    var entityByID: [UUID: Entity] = [:]
    var rawPointClouds: [UUID: PointCloudData] = [:] // not persisted (reloaded from file if needed)

    // MARK: - Import Queue
    func queueImport(url: URL) async {
        let needsAccess = url.startAccessingSecurityScopedResource()
        defer { if needsAccess { url.stopAccessingSecurityScopedResource() } }

        guard FileManager.default.fileExists(atPath: url.path) else {
            lastError = "File not found: \(url.lastPathComponent)"
            return
        }
        pendingImports.append(url)
    }

    func popNextImport() -> URL? {
        guard !pendingImports.isEmpty else { return nil }
        return pendingImports.removeFirst()
    }

    // MARK: - Persistence
    func persistNow() {
        PersistenceManager.save(state)
    }

    func register(entity: Entity, record: EntityRecord) {
        entity.components.set(PersistentIDComponent(id: record.id))
        entityByID[record.id] = entity
        upsert(record: record, persist: true)
    }

    func updateTransform(for entity: Entity) {
        guard let id = entity.persistentID else { return }
        guard let idx = state.items.firstIndex(where: { $0.id == id }) else { return }
        state.items[idx].transform = TransformCodable(entity.transform)
    }

    func removeRecordAndResources(id: UUID) {
        if let idx = state.items.firstIndex(where: { $0.id == id }) {
            let rec = state.items.remove(at: idx)
            PersistenceManager.deleteLocalFile(relative: rec.localRelativePath)
        }
        if let e = entityByID[id] {
            e.removeFromParent()
        }
        entityByID.removeValue(forKey: id)
        rawPointClouds.removeValue(forKey: id)
        persistNow()
    }

    func upsert(record: EntityRecord, persist: Bool) {
        if let i = state.items.firstIndex(where: { $0.id == record.id }) {
            state.items[i] = record
        } else {
            state.items.append(record)
        }
        if persist { persistNow() }
    }

    func record(for id: UUID) -> EntityRecord? {
        state.items.first { $0.id == id }
    }

    // Called by ImmersiveSpaceView at startup
    func restore(in anchor: AnchorEntity) async {
        // Already restored?
        if !entityByID.isEmpty { return }
        for rec in state.items {
            let localURL = PersistenceManager.appSupportURL.appendingPathComponent(rec.localRelativePath)
            do {
                switch rec.kind {
                case .usdz:
                    let entity = try await Entity.load(contentsOf: localURL)
                    entity.transform = rec.transform.asTransform()
                    entity.generateCollisionShapes(recursive: true)
                    entity.components.set(PersistentIDComponent(id: rec.id))
                    anchor.addChild(entity)
                    entityByID[rec.id] = entity

                case .pointCloud:
                    let data = try loadRawPointCloud(from: localURL)
                    rawPointClouds[rec.id] = data
                    let entity = try await PointCloudFactory.makePointCloudEntity(
                        points: data.points,
                        colors: data.colors,
                        maxPoints: rec.point?.maxPoints ?? 20_000,
                        pointRadius: rec.point?.pointRadius ?? 0.006
                    )
                    entity.transform = rec.transform.asTransform()
                    entity.generateCollisionShapes(recursive: true)
                    entity.components.set(PersistentIDComponent(id: rec.id))
                    anchor.addChild(entity)
                    entityByID[rec.id] = entity
                }
            } catch {
                lastError = "Restore failed for \(rec.filename): \(error.localizedDescription)"
            }
        }
    }

    // MARK: - Point cloud helpers
    func loadRawPointCloud(from url: URL) throws -> PointCloudData {
        switch url.pathExtension.lowercased() {
        case "ply": return try PointCloudLoader.loadPLY_ASCII(url: url)
        case "pcd": return try PointCloudLoader.loadPCD_ASCII(url: url)
        case "xyz": return try PointCloudLoader.loadXYZ(url: url)
        default: throw NSError(domain: "Pulto", code: -3, userInfo: [NSLocalizedDescriptionKey: "Unsupported point cloud format"])
        }
    }

    func applyPointRadius(id: UUID, newRadius: Float) {
        guard let parent = entityByID[id] else { return }
        guard let idx = state.items.firstIndex(where: { $0.id == id }) else { return }
        let oldR = state.items[idx].point?.pointRadius ?? 0.006
        guard oldR > 0 else { return }
        let m = newRadius / oldR
        parent.children.forEach { child in
            child.scale *= SIMD3<Float>(repeating: m)
        }
        if state.items[idx].point == nil {
            state.items[idx].point = PointCloudSettings(maxPoints: 20_000, pointRadius: newRadius)
        } else {
            state.items[idx].point!.pointRadius = newRadius
        }
        persistNow()
    }

    func rebuildPointCloud(id: UUID, maxPoints: Int, pointRadius: Float, anchor: AnchorEntity) async {
        guard let rec = record(for: id) else { return }
        let localURL = PersistenceManager.appSupportURL.appendingPathComponent(rec.localRelativePath)
        do {
            let data = try loadRawPointCloud(from: localURL)
            rawPointClouds[id] = data
            let newEntity = try await PointCloudFactory.makePointCloudEntity(
                points: data.points, colors: data.colors,
                maxPoints: max(1_000, maxPoints),
                pointRadius: pointRadius
            )
            newEntity.transform = rec.transform.asTransform()
            newEntity.generateCollisionShapes(recursive: true)
            newEntity.components.set(PersistentIDComponent(id: id))

            if let old = entityByID[id] {
                let parent = old.parent
                old.removeFromParent()
                if let p = parent {
                    p.addChild(newEntity)
                } else {
                    anchor.addChild(newEntity)
                }
            } else {
                anchor.addChild(newEntity)
            }
            entityByID[id] = newEntity

            var updated = rec
            if updated.point == nil {
                updated.point = PointCloudSettings(maxPoints: maxPoints, pointRadius: pointRadius)
            } else {
                updated.point!.maxPoints = maxPoints
                updated.point!.pointRadius = pointRadius
            }
            upsert(record: updated, persist: true)
        } catch {
            lastError = "Rebuild failed: \(error.localizedDescription)"
        }
    }
}

extension Entity {
    var persistentID: UUID? {
        components[PersistentIDComponent.self]?.id
    }
}
