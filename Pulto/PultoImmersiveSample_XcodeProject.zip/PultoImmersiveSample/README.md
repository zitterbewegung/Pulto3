# Pulto Immersive Add-On (visionOS / RealityKit)

This is a drop-in module for your **Pulto** visionOS app that adds an **Immersive Space** with:
- Import **USDZ** and point clouds (**.ply ASCII**, **.pcd ASCII**, **.xyz**)
- Interactive placement (tap select, drag move, pinch scale, rotate)
- Point cloud controls (**Point Size**, **Max Points**) with **Apply**
- **Save Layout** and automatic **restore** on relaunch

## Files
- `PultoApp.swift` – App scene + ImmersiveSpace
- `ContentView.swift` – Planar window UI (open space, import, save)
- `Components.swift` – `PersistentIDComponent` for tracking entities
- `Persistence.swift` – JSON save/load + file management (App Support)
- `SceneModel.swift` – State, import queue, restore, rebuild cloud
- `ImmersiveSpaceView.swift` – RealityView, gestures, HUD/panel UI
- `USDZLoader.swift` – Async USDZ loader helper
- `PointCloudLoader.swift` – ASCII loaders for XYZ/PLY/PCD
- `PointCloudFactory.swift` – Builds a sphere-instanced point cloud entity

## Integrate
1. Add all files to your **visionOS** target in Xcode.
2. Run. In the window:
   - **Open Immersive Space**
   - **Import 3D / LiDAR File** (USDZ/PLY/PCD/XYZ)
3. In immersive:
   - Tap = select, Drag = move (X/Z), Pinch = scale, Rotate = yaw
   - Use **panel** to tweak point size / downsampling, reset, delete, save layout

### Notes
- Point clouds are rendered as **instanced spheres** (shared mesh per point) with optional downsampling.
- Persistence copies imported files into **Application Support/Pulto** and saves a `state.json` scene file.
- Supported point clouds: **ASCII** PLY/PCD only (extend parsers for binary if needed).
