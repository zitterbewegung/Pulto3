import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject var sceneModel: SceneModel
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace

    @State private var isFileImporterPresented = false
    @State private var immersiveOpen = false
    @State private var importerError: String?

    private var allowedTypes: [UTType] {
        [
            UTType(filenameExtension: "usdz"),
            UTType(filenameExtension: "ply"),
            UTType(filenameExtension: "pcd"),
            UTType(filenameExtension: "xyz")
        ]
        .compactMap { $0 }
    }

    var body: some View {
        VStack(spacing: 20) {
            Text("Pulto • 3D Import & Immersive")
                .font(.largeTitle.bold())

            HStack(spacing: 12) {
                Button(immersiveOpen ? "Close Immersive Space" : "Open Immersive Space") {
                    Task {
                        if immersiveOpen {
                            await dismissImmersiveSpace()
                            immersiveOpen = false
                        } else {
                            let result = await openImmersiveSpace(id: "PultoImmersiveSpace")
                            immersiveOpen = (result == .opened)
                            if immersiveOpen {
                                await sceneModel.restoreAllRequested = true
                            }
                        }
                    }
                }
                .buttonStyle(.borderedProminent)

                Button("Import 3D / LiDAR File") {
                    isFileImporterPresented = true
                }
                .buttonStyle(.bordered)
                .disabled(!immersiveOpen)

                Button("Save Layout") {
                    sceneModel.persistNow()
                }
                .buttonStyle(.bordered)
                .disabled(!immersiveOpen)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Supported:")
                Text("• USDZ (.usdz)").font(.callout)
                Text("• Point Clouds: ASCII .ply, ASCII .pcd, .xyz (x y z [r g b])").font(.callout)
            }
            .foregroundStyle(.secondary)

            if let e = importerError {
                Text("Import error: \(e)")
                    .foregroundStyle(.red)
                    .font(.callout)
            }

            if let e = sceneModel.lastError {
                Text("Runtime error: \(e)")
                    .foregroundStyle(.red)
                    .font(.callout)
            }

            Spacer()
        }
        .padding(32)
        .fileImporter(
            isPresented: $isFileImporterPresented,
            allowedContentTypes: allowedTypes,
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                Task { await sceneModel.queueImport(url: url) }
            case .failure(let err):
                importerError = err.localizedDescription
            }
        }
    }
}
