#!/bin/bash
set -eux
dnf update -y
dnf install -y docker git
systemctl enable --now docker
dnf install -y docker-compose

mkdir -p /opt/pg
cat > /opt/pg/docker-compose.yml <<'YML'
version: "3.9"
services:
  postgres:
    image: postgis/postgis:16-3.4
    environment:
      POSTGRES_DB: visionos
      POSTGRES_USER: vision
      POSTGRES_PASSWORD: vision
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./init_postgis.sh:/docker-entrypoint-initdb.d/10_init_postgis.sh:ro
volumes:
  pgdata:
YML

cat > /opt/pg/init_postgis.sh <<'INIT'
#!/usr/bin/env bash
set -e
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-SQL
  CREATE EXTENSION IF NOT EXISTS postgis;
  CREATE EXTENSION IF NOT EXISTS postgis_raster;
  CREATE EXTENSION IF NOT EXISTS pgcrypto;
  CREATE EXTENSION IF NOT EXISTS pointcloud;
  CREATE EXTENSION IF NOT EXISTS pointcloud_postgis;
SQL
INIT
chmod +x /opt/pg/init_postgis.sh

cd /opt/pg
docker compose up -d
