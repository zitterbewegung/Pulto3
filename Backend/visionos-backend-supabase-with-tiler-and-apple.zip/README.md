# VisionOS Backend (FastAPI + PostGIS + IoTDB + S3/MinIO)

## Local Dev
```bash
cp .env.example .env
docker compose up --build
```
- API: http://localhost:8000 (Swagger `/docs`)
- MinIO console: http://localhost:9001
- S3 endpoint: http://localhost:9000

### VisionOS-friendly aliases
- Versioned endpoints available under `/v1/visionos/*` (see below).

### Switch to AWS S3 / RDS
- Set S3 credentials and clear `S3_ENDPOINT` to use AWS S3.
- Point Postgres variables to RDS with PostGIS + pgPointCloud enabled.


## Supabase-first mode

- Set in `.env`:
  ```
  SUPABASE_URL= https://YOUR-PROJECT.supabase.co
  SUPABASE_ANON_KEY= <anon>
  SUPABASE_SERVICE_ROLE_KEY= <service role>
  SUPABASE_STORAGE_BUCKET= visionos-assets
  ```
- For **database**, you may either:
  - use local Timescale/PostGIS (compose default), or
  - point `PGHOST/PGUSER/PGPASSWORD/PGDATABASE` to your **Supabase Postgres** (enable extensions in dashboard: postgis, timescaledb; pgpointcloud is typically not available on hosted Supabase).
- Assets: `/assets/presign/upload` and `/assets/presign/download` now return **Supabase Storage** signed URLs.
- Sensors: stored in Timescale hypertable `sensors`.


## Sign in with Apple (via Supabase Auth)

- Enable **Apple** provider in Supabase Auth settings.
- Configure your **Services ID**, **Team ID**, **Key ID**, and **Private Key** in Supabase.
- On visionOS, use native **ASAuthorizationAppleID**; exchange with Supabase using client SDK (e.g., `signInWithIdToken` for provider `apple`). The backend validates Supabase JWTs automatically and enforces auth on `/v1/visionos/*` when `SUPABASE_URL` is set.
- For testing, call `/v1/visionos/secure/whoami` with `Authorization: Bearer <jwt>` to verify claims.

## 3D Tiler (GitHub Action)

Run the tiler manually:
- Go to **Actions → 3D Tiler → Run workflow** and set:
  - `input_key`: e.g., `raw/site1.laz` (path within your Supabase Storage bucket)
  - `output_prefix`: e.g., `tiles/site1`
  - `grid_size`: e.g., `10`
- The job downloads the raw point cloud, tiles it into **LAZ** grid slices, writes a `tileset.json` manifest, and uploads to Supabase Storage at `output_prefix`.
- Use `/assets/presign/download` to get signed URLs for individual tiles and stream selectively in your VisionOS client.
