#!/usr/bin/env bash
set -euo pipefail
IN=${1:?"Usage: pdal_import.sh <input.las|laz|ply>"}
PIPE=/tmp/pipeline.json
export PGHOST PGDATABASE PGUSER PGPASSWORD
sed "s#%INPUT%#$IN#g" /scripts/pdal_to_pgpointcloud.json.tmpl > $PIPE
echo "Using pipeline:"
cat $PIPE
pdal pipeline $PIPE
