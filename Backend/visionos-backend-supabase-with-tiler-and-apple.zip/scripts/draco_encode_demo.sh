#!/usr/bin/env bash
set -e
IN="$1"
OUT="$2"
: "${DRACO_ENCODER_PATH:=/usr/local/bin/draco_encoder}"
if [ ! -x "$DRACO_ENCODER_PATH" ]; then
  echo "draco_encoder not found at $DRACO_ENCODER_PATH"; exit 1
fi
"$DRACO_ENCODER_PATH" -i "$IN" -o "$OUT" -cl 10 -qp 14
echo "Wrote $OUT"
