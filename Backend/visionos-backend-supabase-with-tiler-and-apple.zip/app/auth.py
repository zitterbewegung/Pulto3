import json, time, base64
from typing import Optional
from fastapi import Request, HTTPException
import httpx
from jose import jwt
from .config import settings

_cached_jwks = None
_cached_ts = 0

async def get_jwks():
    global _cached_jwks, _cached_ts
    now = time.time()
    if _cached_jwks and now - _cached_ts < 3600:
        return _cached_jwks
    url = f"{settings.SUPABASE_URL.rstrip('/')}/auth/v1/jwks"
    async with httpx.AsyncClient(timeout=5) as client:
        r = await client.get(url)
        r.raise_for_status()
        _cached_jwks = r.json()
        _cached_ts = now
        return _cached_jwks

async def supabase_auth(request: Request) -> Optional[dict]:
    if not settings.SUPABASE_URL:
        return None  # auth disabled
    auth = request.headers.get("Authorization")
    if not auth or not auth.lower().startswith("bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = auth.split(" ",1)[1]
    jwks = await get_jwks()
    try:
        claims = jwt.decode(token, jwks, algorithms=['RS256'], options={"verify_aud": False})
        return claims
    except Exception as e:
        raise HTTPException(401, f"Invalid token: {e}")
