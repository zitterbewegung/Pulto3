from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import requests
from ..config import settings

router = APIRouter(prefix="/omniverse", tags=["omniverse"])

class StreamRequest(BaseModel):
    scene_id: str
    quality: str = "high"

@router.post("/stream/start")
def start_stream(req: StreamRequest):
    headers = {"Authorization": f"Bearer {settings.OMNI_API_KEY}"}
    url = f"{settings.Omni_BASE_URL if hasattr(settings,'Omni_BASE_URL') else settings.OMNI_BASE_URL}/streams"
    try:
        r = requests.post(url, headers=headers, json=req.model_dump(), timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        raise HTTPException(502, f"Omniverse proxy failed: {e}")
