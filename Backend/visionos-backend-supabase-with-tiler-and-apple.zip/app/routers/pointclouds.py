from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..deps import db_dep
from ..spatial import insert_point_block, query_bbox
from ..tiles import simple_octree_tile_indices

router = APIRouter(prefix="/pointclouds", tags=["pointclouds"])

class PointsBlock(BaseModel):
    points: list[tuple[float, float, float, float]]  # x,y,z,intensity

@router.post("/ingest/points")
def ingest_points(payload: PointsBlock, db: Session = Depends(db_dep)):
    if not payload.points:
        raise HTTPException(400, "empty points")
    insert_point_block(db, payload.points)
    return {"ok": True, "inserted": len(payload.points)}

@router.get("/query/bbox")
def bbox_query(
    minx: float = Query(...), miny: float = Query(...), minz: float = Query(...),
    maxx: float = Query(...), maxy: float = Query(...), maxz: float = Query(...),
    db: Session = Depends(db_dep)
):
    rows = query_bbox(db, minx,miny,minz,maxx,maxy,maxz)
    return {"count": len(rows), "patches": [{"id": r.id, "wkt": r.wkt} for r in rows]}

class TileQuery(BaseModel):
    bbox: list[float]
    level: int
    view_center: tuple[float,float,float]

@router.post("/tiles")
def get_tiles(q: TileQuery):
    tiles = simple_octree_tile_indices(tuple(q.bbox), q.level, q.view_center)
    return {"level": q.level, "tiles": tiles}
