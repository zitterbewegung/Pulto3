from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    API_TITLE: str = "VisionOS Backend"
    API_DEBUG: bool = True

    PGHOST: str = "postgres"
    PGPORT: int = 5432
    PGDATABASE: str = "visionos"
    PGUSER: str = "vision"
    PGPASSWORD: str = "vision"

    S3_BUCKET_ASSETS: str = "visionos-assets"
    S3_ENDPOINT: str | None = "http://minio:9000"
    S3_REGION: str = "us-east-1"
    S3_ACCESS_KEY_ID: str = "minioadmin"
    S3_SECRET_ACCESS_KEY: str = "minioadmin"
    S3_FORCE_PATH_STYLE: bool = True

    IOTDB_HOST: str = "iotdb"
    IOTDB_PORT: int = 6667
    IOTDB_USER: str = "root"
    IOTDB_PASSWORD: str = "root"
    IOTDB_STORAGE_GROUP: str = "root.vision"

    OMNI_BASE_URL: str = "https://api.omniverse.example.com"
    OMNI_API_KEY: str = "replace-me"

    DRACO_ENCODER_PATH: str = "/usr/local/bin/draco_encoder"

settings = Settings()


    SUPABASE_URL: str | None = None
