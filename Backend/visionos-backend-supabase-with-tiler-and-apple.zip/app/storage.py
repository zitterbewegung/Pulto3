from supabase import create_client, Client
from .config import settings

def supa() -> Client:
    if not settings.SUPABASE_URL or not settings.SUPABASE_SERVICE_ROLE_KEY:
        raise RuntimeError("Supabase not configured: set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    return create_client(settings.SUPABASE_URL, settings.SUPABASE_SERVICE_ROLE_KEY)

def presign_upload(key: str, expires: int = 3600) -> str:
    # Supabase Storage signed upload URL (create signed URL for PUT via signed URL token)
    sb = supa()
    res = sb.storage.from_(settings.SUPABASE_STORAGE_BUCKET).create_signed_upload_url(key, expires_in=expires)
    return res.get("signedUrl") or res.get("url")

def presign_download(key: str, expires: int = 3600) -> str:
    sb = supa()
    res = sb.storage.from_(settings.SUPABASE_STORAGE_BUCKET).create_signed_url(key, expires_in=expires)
    return res.get("signedURL") or res.get("signedUrl") or res.get("url")
