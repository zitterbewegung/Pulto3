import boto3
from botocore.config import Config
from .config import settings

def s3_client():
    kwargs = dict(
        aws_access_key_id=settings.S3_ACCESS_KEY_ID,
        aws_secret_access_key=settings.S3_SECRET_ACCESS_KEY,
        region_name=settings.S3_REGION,
        config=Config(s3={"addressing_style": "path"} if settings.S3_FORCE_PATH_STYLE else {})
    )
    if settings.S3_ENDPOINT:
        kwargs["endpoint_url"] = settings.S3_ENDPOINT
    return boto3.client("s3", **kwargs)

def presign_put(key: str, content_type: str, expires=3600) -> str:
    return s3_client().generate_presigned_url(
        "put_object",
        Params={"Bucket": settings.S3_BUCKET_ASSETS, "Key": key, "ContentType": content_type},
        ExpiresIn=expires
    )

def presign_get(key: str, expires=3600) -> str:
    return s3_client().generate_presigned_url(
        "get_object",
        Params={"Bucket": settings.S3_BUCKET_ASSETS, "Key": key},
        ExpiresIn=expires
    )
