from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .routers import assets, pointclouds, sensors, omniverse

tags = [
    {"name":"assets","description":"S3/MinIO asset presign + metadata"},
    {"name":"pointclouds","description":"Ingest/query pgPointCloud + tiles"},
    {"name":"sensors","description":"100Hz time-series in IoTDB"},
    {"name":"omniverse","description":"Start/relay Omniverse streams (stub)"},
]

app = FastAPI(title=settings.API_TITLE, debug=settings.API_DEBUG, openapi_url="/openapi.json", openapi_tags=tags)

# CORS for VisionOS app (adjust origins for production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Primary routers
app.include_router(assets.router)
app.include_router(pointclouds.router)
app.include_router(sensors.router)
app.include_router(omniverse.router)

# VisionOS aliases ("wiring" common prefixes your app might already use)
from fastapi import APIRouter

# If SUPABASE_URL is set, require auth on /v1/visionos/*
auth_guard = [Depends(supabase_auth)]
try:
    from .config import settings as _s
    _supabase_enabled = bool(_s.SUPABASE_URL)
except Exception:
    _supabase_enabled = False

if _supabase_enabled:
    v1 = APIRouter(prefix="/v1/visionos", tags=["visionos-aliases"], dependencies=auth_guard)
else:
    v1 = APIRouter(prefix="/v1/visionos", tags=["visionos-aliases"])

v1.include_router(assets.router, prefix="/assets")
v1.include_router(pointclouds.router, prefix="/pointclouds")
v1.include_router(sensors.router, prefix="/sensors")
v1.include_router(omniverse.router, prefix="/omniverse")
app.include_router(v1)

legacy = APIRouter(prefix="/visionos", tags=["legacy"])
legacy.include_router(assets.router, prefix="/assets")
legacy.include_router(pointclouds.router, prefix="/pointclouds")
legacy.include_router(sensors.router, prefix="/sensors")
legacy.include_router(omniverse.router, prefix="/omniverse")
app.include_router(legacy)

api_flat = APIRouter(prefix="/api", tags=["api-flat"])
api_flat.include_router(assets.router, prefix="/assets")
api_flat.include_router(pointclouds.router, prefix="/pointclouds")
api_flat.include_router(sensors.router, prefix="/sensors")
api_flat.include_router(omniverse.router, prefix="/omniverse")
app.include_router(api_flat)

from fastapi import Depends, Request
from .auth import supabase_auth

secure = APIRouter(prefix="/v1/visionos/secure", tags=["visionos-secure"])
@secure.get("/whoami")
async def whoami(claims: dict | None = Depends(supabase_auth)):
    return {"claims": claims}

secure.include_router(assets.router, prefix="/assets", dependencies=[Depends(supabase_auth)])
secure.include_router(pointclouds.router, prefix="/pointclouds", dependencies=[Depends(supabase_auth)])
secure.include_router(sensors.router, prefix="/sensors", dependencies=[Depends(supabase_auth)])
app.include_router(secure)

@app.get("/")
def root():
    return {"service": settings.API_TITLE, "ok": True}

@app.get("/v1/visionos/capabilities")
def caps():
    return {
        "assets": ["presign/upload","presign/download","metadata"],
        "pointclouds": ["ingest/points","query/bbox","tiles"],
        "sensors": ["ingest","query"],
        "omniverse": ["stream/start"],
        "notes": "These endpoints are aliased under /v1/visionos/* for client wiring."
    }
