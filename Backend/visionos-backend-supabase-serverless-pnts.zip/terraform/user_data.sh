#!/bin/bash
set -eux

dnf update -y
dnf install -y docker git jq
systemctl enable --now docker
dnf install -y docker-compose

mkdir -p /opt/visionos-backend
cd /opt/visionos-backend

cat > .env <<ENVV
API_TITLE=VisionOS Backend
API_DEBUG=false

PGHOST=postgres
PGPORT=5432
PGDATABASE=${PGDATABASE}
PGUSER=${PGUSER}
PGPASSWORD=${PGPASSWORD}

S3_BUCKET_ASSETS=${S3_BUCKET_ASSETS}
S3_ENDPOINT=http://minio:9000
S3_REGION=us-east-1
S3_ACCESS_KEY_ID=${MINIO_ROOT_USER}
S3_SECRET_ACCESS_KEY=${MINIO_ROOT_PASSWORD}
S3_FORCE_PATH_STYLE=true

IOTDB_HOST=iotdb
IOTDB_PORT=6667
IOTDB_USER=root
IOTDB_PASSWORD=root
IOTDB_STORAGE_GROUP=root.vision

OMNI_BASE_URL=https://api.omniverse.example.com
OMNI_API_KEY=${OMNI_API_KEY}

DRACO_ENCODER_PATH=/usr/local/bin/draco_encoder
ENVV

cat > docker-compose.yml <<'COMPOSE'
version: "3.9"
services:
  api:
    build: .
    container_name: visionos_api
    env_file: .env
    ports:
      - "8000:8000"
    depends_on:
      - postgres
      - minio
      - iotdb
    volumes:
      - ./app:/app
      - ./scripts:/scripts
    command: >
      sh -c "
      /scripts/wait-for-it.sh postgres:5432 --timeout=60 --strict --
      /scripts/wait-for-it.sh minio:9000 --timeout=60 --strict --
      /scripts/wait-for-it.sh iotdb:6667 --timeout=60 --strict --
      uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
      "
  postgres:
    image: postgis/postgis:16-3.4
    container_name: visionos_postgis
    environment:
      POSTGRES_DB: ${PGDATABASE:-visionos}
      POSTGRES_USER: ${PGUSER:-vision}
      POSTGRES_PASSWORD: ${PGPASSWORD:-vision}
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./scripts/init_postgis.sh:/docker-entrypoint-initdb.d/10_init_postgis.sh:ro
  iotdb:
    image: apache/iotdb:1.3.2
    container_name: visionos_iotdb
    environment:
      IOTDB_RPC_ADDRESS: 0.0.0.0
    ports:
      - "6667:6667"
    volumes:
      - iotdbdata:/iotdb/data
      - iotdblogs:/iotdb/logs
  minio:
    image: minio/minio:RELEASE.2025-01-05T00-00-00Z
    container_name: visionos_minio
    environment:
      MINIO_ROOT_USER: ${MINIO_ROOT_USER:-minioadmin}
      MINIO_ROOT_PASSWORD: ${MINIO_ROOT_PASSWORD:-minioadmin}
    command: server /data --console-address ":9001"
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - miniodata:/data
  createbuckets:
    image: minio/mc:RELEASE.2025-01-05T00-00-00Z
    depends_on:
      - minio
    entrypoint: >
      /bin/sh -c "
      /scripts/wait-for-it.sh minio:9000 --timeout=60 --strict --
      mc alias set local http://minio:9000 ${MINIO_ROOT_USER:-minioadmin} ${MINIO_ROOT_PASSWORD:-minioadmin};
      mc mb -p local/${S3_BUCKET_ASSETS:-visionos-assets} || true;
      mc anonymous set download local/${S3_BUCKET_ASSETS:-visionos-assets};
      "
    volumes:
      - ./scripts:/scripts
volumes:
  pgdata:
  iotdbdata:
  iotdblogs:
  miniodata:

COMPOSE

# write minimal app (fetch from S3/Git in real deployments)
cat > bootstrap.txt <<'NOTE'
Upload the project files to this instance or mount a volume.
This user_data wrote .env and docker-compose.yml only.
NOTE

docker compose up -d
