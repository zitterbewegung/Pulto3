# Cloud Run Terraform (Serverless)

## Enable APIs
```
gcloud services enable run.googleapis.com artifactregistry.googleapis.com iamcredentials.googleapis.com
```

## Deploy
```
cd terraform/serverless/gcp
terraform init
terraform apply -auto-approve -var="project_id=YOUR_GCP_PROJECT" -var="region=us-central1"   -var="supabase_url=https://XYZ.supabase.co"   -var="supabase_anon_key=..."   -var="supabase_service_role_key=..."   -var="supabase_storage_bucket=visionos-assets"
```

Then push an image to Artifact Registry named:
`${region}-docker.pkg.dev/${project_id}/${artifact_repo}/${service_name}:latest`
