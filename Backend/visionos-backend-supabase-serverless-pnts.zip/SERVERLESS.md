# Serverless Deployment Guide (Supabase + Cloud Run)

This backend can be deployed **fully serverless** by combining:
- **Supabase** for Auth (incl. Sign in with Apple), Postgres (PostGIS/Timescale), and Storage.
- **Google Cloud Run** for the FastAPI container (autoscaling to zero).
- **GitHub Actions** (OIDC) to build/push to Artifact Registry and deploy to Cloud Run.
- **GitHub Actions (Tiler)** for PDAL-based offline tiling jobs (serverless compute runner).

> ⚠️ Note: Hosted Supabase generally does **not** provide the `pointcloud` extension. For raw pgPointCloud, use an external Postgres with that extension. In a serverless-first setup, prefer **tiles in Supabase Storage** + spatial metadata in PostGIS.

---

## Architecture

```
VisionOS app  ──────▶ Cloud Run (FastAPI)
   │                       │
   │ JWT (Supabase)        ├──▶ Supabase Postgres (PostGIS/Timescale)
   │                       └──▶ Supabase Storage (assets/tiles)
   └────────────── GitHub Actions (tiler) ──▶ PDAL tiling ──▶ Storage
```

- **Auth:** Supabase JWT is required for `/v1/visionos/*` routes if `SUPABASE_URL` is configured.
- **Assets:** Presign Supabase Storage URLs (`/assets/presign/*`) to upload/download USDZ/tiles.
- **Sensors:** Stored in Timescale hypertable (`sensors`) on Supabase Postgres (or local dev DB).
- **Point clouds:** Use the **3D tiler** GitHub Action to generate LAZ tiles + `tileset.json` and serve to the headset via signed URLs.

---

## Cloud Run (Terraform)

This repo includes Terraform under `terraform/serverless/gcp` to:
- create an **Artifact Registry** repo for the image,
- deploy a **Cloud Run** service,
- set required environment variables for the container.

### Prerequisites

- A Google Cloud project with billing enabled.
- Enable APIs: `run.googleapis.com`, `artifactregistry.googleapis.com`, `iamcredentials.googleapis.com`.
- Create a workload identity provider for GitHub OIDC (optional, but recommended for CI deploy).

### Variables

See `terraform/serverless/gcp/variables.tf`:
- `project_id`, `region` (e.g., `us-central1`)
- `service_name` (default: `visionos-backend`)
- `artifact_repo` (default: `visionos`)

**Environment variables (Cloud Run)** are passed via Terraform:
- `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_STORAGE_BUCKET`
- `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD` (if pointing to Supabase DB)

> For Supabase Postgres, use the connection info from the Supabase dashboard.

### Commands

```bash
cd terraform/serverless/gcp
terraform init
terraform apply -auto-approve   -var="project_id=YOUR_GCP_PROJECT"   -var="region=us-central1"   -var="supabase_url=https://XYZ.supabase.co"   -var="supabase_anon_key=..."   -var="supabase_service_role_key=..."   -var="supabase_storage_bucket=visionos-assets"   -var="pg_host=db.XYZ.supabase.co"   -var="pg_port=5432"   -var="pg_database=postgres"   -var="pg_user=postgres"   -var="pg_password=..."
```

Outputs include the Cloud Run URL.

---

## GitHub Actions: Serverless Deploy

Workflow: `.github/workflows/deploy-cloudrun.yml`

- Builds the Docker image,
- Authenticates to GCP via OIDC,
- Pushes to **Artifact Registry**,
- Deploys to **Cloud Run** with env vars from repo secrets.

**Repo Secrets required** (example):
- `GCP_PROJECT_ID`
- `GCP_REGION` (e.g., `us-central1`)
- `GCP_WORKLOAD_ID_PROVIDER` (resource name)
- `GCP_SERVICE_ACCOUNT_EMAIL` (with Artifact Registry + Cloud Run deploy perms)
- `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_STORAGE_BUCKET`
- (Optional) `PGHOST`, `PGPORT`, `PGDATABASE`, `PGUSER`, `PGPASSWORD`

---

## VisionOS Endpoint Wiring

- All public endpoints available under: `/v1/visionos/*` (auth required if `SUPABASE_URL` set).
- Secure endpoints also under: `/v1/visionos/secure/*`.
- Legacy aliases: `/visionos/*`, `/api/*`.

---

## Tiler (Serverless Job)

- Use the **3D Tiler** Action (`.github/workflows/tiler.yml`) to generate LAZ tiles + `tileset.json` and upload to Supabase Storage.
- VisionOS app fetches manifest and requests signed tile URLs via `/assets/presign/download?key=...`.

---

## Notes

- Scaling: Cloud Run auto-scales based on request concurrency; set minimum instances = 0 to scale to zero.
- Cold starts: Consider 1 min instance if you want lower latency.
- CORS: default `*` in dev; restrict in prod.
- Supabase RLS: protect tables (assets metadata, sensors) as needed; backend can use service role and clients use anon tokens.
