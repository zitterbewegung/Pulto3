#!/usr/bin/env python3
import argparse, json, math, os, pathlib, subprocess, tempfile

def pdal_info_bounds(path):
    # Get bounds from pdal info
    out = subprocess.check_output(["pdal", "info", "--summary", path], text=True)
    # Very naive parse; users can replace with robust JSON parse if available
    try:
        js = json.loads(out)
    except Exception:
        # Try --metadata
        out = subprocess.check_output(["pdal", "info", "--metadata", path], text=True)
        js = json.loads(out)
    # Navigate to bounds
    # PDAL metadata varies; attempt common keys
    bounds = None
    if 'summary' in js and 'bounds' in js['summary']:
        b = js['summary']['bounds']
        bounds = [b['minx'], b['miny'], b.get('minz', 0), b['maxx'], b['maxy'], b.get('maxz', 0)]
    elif 'metadata' in js and 'bounds' in js['metadata']:
        b = js['metadata']['bounds']
        bounds = [b['minx'], b['miny'], b.get('minz', 0), b['maxx'], b['maxy'], b.get('maxz', 0)]
    if not bounds:
        raise SystemExit("Could not determine bounds via pdal info")
    return bounds

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Input LAS/LAZ/PLY")
    ap.add_argument("--outdir", required=True, help="Output directory")
    ap.add_argument("--grid-size", type=float, default=10.0, help="Grid size (local units)")
    args = ap.parse_args()

    inp = pathlib.Path(args.input)
    outdir = pathlib.Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    minx, miny, minz, maxx, maxy, maxz = pdal_info_bounds(str(inp))
    gx = args.grid_size
    gy = args.grid_size
    nx = max(1, math.ceil((maxx - minx) / gx))
    ny = max(1, math.ceil((maxy - miny) / gy))

    tiles = []
    for ix in range(nx):
        for iy in range(ny):
            x0 = minx + ix * gx
            x1 = min(x0 + gx, maxx)
            y0 = miny + iy * gy
            y1 = min(y0 + gy, maxy)
            name = f"tile_x{ix}_y{iy}.laz"
            outp = outdir / name
            bounds = f"([{x0},{x1}],[{y0},{y1}])"
            pipeline = {
                "pipeline": [
                    str(inp),
                    {"type": "filters.crop", "bounds": bounds},
                    {"type": "writers.las", "filename": str(outp), "compression": "laszip"}
                ]
            }
            pipefile = outdir / f"pipe_{ix}_{iy}.json"
            pipefile.write_text(json.dumps(pipeline))
            subprocess.run(["pdal", "pipeline", str(pipefile)], check=True)
            tiles.append({"name": name, "bbox": [x0,y0,minz,x1,y1,maxz]})

    # Write a lightweight manifest (inspired by 3D Tiles tileset, not full spec)
    tileset = {
        "asset": {"version":"0.0.1","type":"grid-laz"},
        "bounds": [minx,miny,minz,maxx,maxy,maxz],
        "gridSize": [gx, gy],
        "tiles": tiles
    }
    (outdir / "tileset.json").write_text(json.dumps(tileset, indent=2))
    print(f"Wrote {len(tiles)} tiles and tileset.json to {outdir}")

if __name__ == "__main__":
    main()
