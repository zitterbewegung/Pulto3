#!/usr/bin/env python3

import argparse, json, math, os, pathlib, struct, sys
import numpy as np

try:
    import laspy
except Exception as e:
    print("laspy is required. pip install laspy", file=sys.stderr); raise

def write_pnts(out_path: pathlib.Path, xyz: np.ndarray, rgb: np.ndarray | None, bbox):
    # 3D Tiles PNTS minimal with quantized positions
    minx, miny, minz, maxx, maxy, maxz = bbox
    scale = np.array([maxx-minx, maxy-miny, maxz-minz], dtype=np.float64)
    scale[scale==0] = 1.0
    # quantize to uint16 per spec example (not mandatory but common)
    qpos = ((xyz - np.array([minx, miny, minz])) / scale * 65535.0 + 0.5).astype(np.uint16)

    feature_table_json = {
        "POINTS_LENGTH": int(xyz.shape[0]),
        "POSITION_QUANTIZED": {"byteOffset": 0},
        "QUANTIZED_VOLUME_OFFSET": [float(minx), float(miny), float(minz)],
        "QUANTIZED_VOLUME_SCALE": [float(scale[0]), float(scale[1]), float(scale[2])],
    }

    feature_bin = qpos.tobytes(order="C")
    offset = len(feature_bin)

    if rgb is not None:
        feature_table_json["RGB"] = {"byteOffset": offset}
        feature_bin += rgb.astype(np.uint8).tobytes(order="C")

    # align JSON to 8 bytes
    ftj = json.dumps(feature_table_json, separators=(',',':')).encode("utf-8")
    def pad8(b): 
        return b + b"\x20" * ((8 - (len(b) % 8)) % 8)
    ftj_padded = pad8(ftj)
    ftb_padded = pad8(feature_bin)
    batch_json = b"{}"
    batch_json_padded = pad8(batch_json)
    batch_bin = b""

    magic = b'pnts'
    version = 1
    header_len = 28
    feature_json_len = len(ftj_padded)
    feature_bin_len = len(ftb_padded)
    batch_json_len = len(batch_json_padded)
    batch_bin_len = len(batch_bin)
    total_len = header_len + feature_json_len + feature_bin_len + batch_json_len + batch_bin_len

    with open(out_path, "wb") as f:
        f.write(magic)
        f.write(struct.pack("<I", version))
        f.write(struct.pack("<I", total_len))
        f.write(struct.pack("<I", feature_json_len))
        f.write(struct.pack("<I", feature_bin_len))
        f.write(struct.pack("<I", batch_json_len))
        f.write(struct.pack("<I", batch_bin_len))
        f.write(ftj_padded)
        f.write(ftb_padded)
        f.write(batch_json_padded)
        f.write(batch_bin)

def laz_to_pnts(laz_path: pathlib.Path, pnts_path: pathlib.Path, bbox=None):
    with laspy.open(laz_path) as reader:
        pts = reader.read()
    has_rgb = all(hasattr(pts, c) for c in ("red","green","blue"))
    xyz = np.vstack((pts.x, pts.y, pts.z)).T.astype(np.float64)
    if bbox is None:
        minx, miny, minz = np.min(xyz, axis=0)
        maxx, maxy, maxz = np.max(xyz, axis=0)
        bbox = (float(minx), float(miny), float(minz), float(maxx), float(maxy), float(maxz))
    rgb = None
    if has_rgb:
        # normalize to 0-255 if 16-bit (common LAS)
        r = pts.red.astype(np.float64)
        g = pts.green.astype(np.float64)
        b = pts.blue.astype(np.float64)
        maxv = max(r.max(), g.max(), b.max(), 255.0)
        scale = 255.0 / maxv if maxv > 255 else 1.0
        rgb = np.vstack((r*scale, g*scale, b*scale)).T.astype(np.uint8)
    write_pnts(pnts_path, xyz, rgb, bbox)
    return bbox, xyz.shape[0]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Input LAZ path")
    ap.add_argument("--output", required=True, help="Output PNTS path")
    ap.add_argument("--bbox", help="bbox as minx,miny,minz,maxx,maxy,maxz", default=None)
    args = ap.parse_args()

    bbox = tuple(map(float, args.bbox.split(","))) if args.bbox else None
    bbox, n = laz_to_pnts(pathlib.Path(args.input), pathlib.Path(args.output), bbox)
    print(json.dumps({"bbox": bbox, "points": n}))

if __name__ == "__main__":
    main()
