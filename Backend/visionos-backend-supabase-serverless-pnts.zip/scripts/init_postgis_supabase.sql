-- Init PostGIS, TimescaleDB, pgPointCloud, tables
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_raster;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS timescaledb;
CREATE EXTENSION IF NOT EXISTS pointcloud;
CREATE EXTENSION IF NOT EXISTS pointcloud_postgis;

-- Assets metadata
CREATE TABLE IF NOT EXISTS assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  content_type TEXT,
  bytes BIGINT,
  draco_compressed BOOLEAN DEFAULT FALSE,
  bbox_minx DOUBLE PRECISION,
  bbox_miny DOUBLE PRECISION,
  bbox_minz DOUBLE PRECISION,
  bbox_maxx DOUBLE PRECISION,
  bbox_maxy DOUBLE PRECISION,
  bbox_maxz DOUBLE PRECISION,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Point cloud storage
CREATE TABLE IF NOT EXISTS lidar (
  id BIGSERIAL PRIMARY KEY,
  blk pcpatch
);

-- PCID schema if not exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pointcloud_formats WHERE pcid=1) THEN
    INSERT INTO pointcloud_formats (pcid, srid, schema) VALUES
    (1, 0,
     '<?xml version="1.0" encoding="UTF-8"?>
      <pc:PointCloudSchema xmlns:pc="http://pointcloud.org/schemas/PC/1.1">
        <pc:dimension><pc:name>X</pc:name><pc:size>8</pc:size><pc:interpretation>double</pc:interpretation></pc:dimension>
        <pc:dimension><pc:name>Y</pc:name><pc:size>8</pc:size><pc:interpretation>double</pc:interpretation></pc:dimension>
        <pc:dimension><pc:name>Z</pc:name><pc:size>8</pc:size><pc:interpretation>double</pc:interpretation></pc:dimension>
        <pc:dimension><pc:name>Intensity</pc:name><pc:size>4</pc:size><pc:interpretation>float</pc:interpretation></pc:dimension>
      </pc:PointCloudSchema>'
    );
  END IF;
END$$;

-- High-frequency sensors (Timescale hypertable)
CREATE TABLE IF NOT EXISTS sensors (
  device TEXT NOT NULL,
  ts TIMESTAMPTZ NOT NULL,
  measurements JSONB NOT NULL,
  PRIMARY KEY (device, ts)
);
SELECT create_hypertable('sensors', 'ts', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS sensors_ts_idx ON sensors (ts DESC);
CREATE INDEX IF NOT EXISTS sensors_dev_idx ON sensors (device);
CREATE INDEX IF NOT EXISTS sensors_gin ON sensors USING GIN (measurements);


-- Tilesets registry (store canonical tileset.json with relative URIs)
CREATE TABLE IF NOT EXISTS tilesets (
  name TEXT PRIMARY KEY,
  root_json JSONB NOT NULL,
  storage_prefix TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);
