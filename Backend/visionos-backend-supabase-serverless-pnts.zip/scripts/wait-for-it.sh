#!/usr/bin/env bash
set -e
HOSTPORT=$1
HOST=${HOSTPORT%:*}
PORT=${HOSTPORT#*:}
TIMEOUT=${2:-60}
STRICT=${3:-}
for i in $(seq 1 $TIMEOUT); do
  if nc -z "$HOST" "$PORT" >/dev/null 2>&1; then exit 0; fi
  sleep 1
done
if [ "$STRICT" = "--strict" ]; then
  echo "Timeout waiting for $HOST:$PORT" >&2; exit 1
fi
exit 0
