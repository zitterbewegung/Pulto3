#!/usr/bin/env bash
set -e
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-SQL
  CREATE EXTENSION IF NOT EXISTS postgis;
  CREATE EXTENSION IF NOT EXISTS postgis_raster;
  CREATE EXTENSION IF NOT EXISTS pgcrypto;
  CREATE EXTENSION IF NOT EXISTS pointcloud;
  CREATE EXTENSION IF NOT EXISTS pointcloud_postgis;

  CREATE TABLE IF NOT EXISTS assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key TEXT UNIQUE NOT NULL,
    content_type TEXT,
    bytes BIGINT,
    draco_compressed BOOLEAN DEFAULT FALSE,
    bbox_minx DOUBLE PRECISION,
    bbox_miny DOUBLE PRECISION,
    bbox_minz DOUBLE PRECISION,
    bbox_maxx DOUBLE PRECISION,
    bbox_maxy DOUBLE PRECISION,
    bbox_maxz DOUBLE PRECISION,
    created_at TIMESTAMPTZ DEFAULT now()
  );

  CREATE TABLE IF NOT EXISTS lidar (
    id BIGSERIAL PRIMARY KEY,
    blk pcpatch
  );
SQL

psql --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-SQL
  DO $$
  BEGIN
    IF NOT EXISTS (SELECT 1 FROM pointcloud_formats WHERE pcid=1) THEN
      INSERT INTO pointcloud_formats (pcid, srid, schema) VALUES
      (1, 0,
       '<?xml version="1.0" encoding="UTF-8"?>
        <pc:PointCloudSchema xmlns:pc="http://pointcloud.org/schemas/PC/1.1">
          <pc:dimension><pc:name>X</pc:name><pc:size>8</pc:size><pc:interpretation>double</pc:interpretation></pc:dimension>
          <pc:dimension><pc:name>Y</pc:name><pc:size>8</pc:size><pc:interpretation>double</pc:interpretation></pc:dimension>
          <pc:dimension><pc:name>Z</pc:name><pc:size>8</pc:size><pc:interpretation>double</pc:interpretation></pc:dimension>
          <pc:dimension><pc:name>Intensity</pc:name><pc:size>4</pc:size><pc:interpretation>float</pc:interpretation></pc:dimension>
        </pc:PointCloudSchema>'
      );
    END IF;
  END$$;
SQL
