from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .config import settings

PG_URL = (
    f"postgresql+psycopg://{settings.PGUSER}:{settings.PGPASSWORD}"
    f"@{settings.PGHOST}:{settings.PGPORT}/{settings.PGDATABASE}"
)

engine = create_engine(PG_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
