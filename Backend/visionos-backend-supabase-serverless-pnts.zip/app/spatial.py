from sqlalchemy import text
from sqlalchemy.orm import Session

def insert_point_block(db: Session, points: list[tuple[float,float,float,float]]):
    if not points:
        return
    values = ",".join([f"({x},{y},{z},{i})" for x,y,z,i in points])
    sql = text(f"""
        WITH pts AS (
            SELECT 1 AS pcid, * FROM (VALUES {values}) AS t(x,y,z,intensity)
        ),
        pc AS (
            SELECT PC_Patch(PC_Union(PC_Point(pcid, ARRAY[x,y,z,intensity]))) AS patch FROM pts
        )
        INSERT INTO lidar(blk) SELECT patch FROM pc;
    """)
    db.execute(sql)
    db.commit()

def query_bbox(db: Session, minx: float, miny: float, minz: float, maxx: float, maxy: float, maxz: float):
    sql = text("""
        SELECT id, PC_AsText(blk) AS wkt
        FROM lidar
        WHERE PC_Intersects(blk, PC_MakeBox3D(:minx,:miny,:minz,:maxx,:maxy,:maxz));
    """)
    return db.execute(sql, dict(minx=minx, miny=miny, minz=minz, maxx=maxx, maxy=maxy, maxz=maxz)).all()
