from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import String, Boolean, BigInteger, Double, TIMESTAMP, text
import uuid

class Base(DeclarativeBase):
    pass

class Asset(Base):
    __tablename__ = "assets"
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, server_default=text("gen_random_uuid()"))
    key: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    content_type: Mapped[str | None] = mapped_column(String)
    bytes: Mapped[int | None] = mapped_column(BigInteger)
    draco_compressed: Mapped[bool] = mapped_column(Boolean, default=False)
    bbox_minx: Mapped[float | None] = mapped_column(Double)
    bbox_miny: Mapped[float | None] = mapped_column(Double)
    bbox_minz: Mapped[float | None] = mapped_column(Double)
    bbox_maxx: Mapped[float | None] = mapped_column(Double)
    bbox_maxy: Mapped[float | None] = mapped_column(Double)
    bbox_maxz: Mapped[float | None] = mapped_column(Double)
    created_at: Mapped[str] = mapped_column(TIMESTAMP(timezone=True), server_default=text("now()"))
