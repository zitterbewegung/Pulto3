def simple_octree_tile_indices(bbox, level: int, view_center: tuple[float,float,float]) -> list[str]:
    (minx,miny,minz,maxx,maxy,maxz) = bbox
    cx,cy,cz = view_center
    tiles = []
    for i in range(8):
        tiles.append(f"lvl{level}/tile_{i}_{int(cx)}_{int(cy)}_{int(cz)}.pnts")
    return tiles
