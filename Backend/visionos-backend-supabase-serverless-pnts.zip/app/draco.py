import subprocess
from pathlib import Path
from .config import settings

def draco_compress(in_path: str, out_path: str) -> None:
    enc = settings.DRACO_ENCODER_PATH
    if not Path(enc).exists():
        raise RuntimeError(f"draco_encoder not found at {enc}")
    subprocess.run([enc, "-i", in_path, "-o", out_path, "-cl", "10", "-qp", "14"], check=True)
