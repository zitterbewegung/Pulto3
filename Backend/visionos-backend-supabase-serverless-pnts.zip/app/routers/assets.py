from fastapi import APIRouter, HTTPException, Query, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..deps import db_dep
from ..storage import presign_upload, presign_download
from ..models import Asset

router = APIRouter(prefix="/assets", tags=["assets"])

class PresignUploadRequest(BaseModel):
    key: str
    content_type: str | None = None

@router.post("/presign/upload")
def supabase_presign_upload(req: PresignUploadRequest):
    url = presign_upload(req.key)
    return {"url": url}

@router.get("/presign/download")
def supabase_presign_download(key: str = Query(...)):
    url = presign_download(key)
    return {"url": url}

class AssetMeta(BaseModel):
    key: str
    content_type: str | None = None
    bytes: int | None = None
    draco_compressed: bool = False
    bbox_minx: float | None = None
    bbox_miny: float | None = None
    bbox_minz: float | None = None
    bbox_maxx: float | None = None
    bbox_maxy: float | None = None
    bbox_maxz: float | None = None

@router.post("/metadata")
def upsert_metadata(meta: AssetMeta, db: Session = Depends(db_dep)):
    existing = db.query(Asset).filter(Asset.key == meta.key).one_or_none()
    if existing:
        for k, v in meta.model_dump().items():
            setattr(existing, k, v)
        db.commit()
        return {"updated": True}
    a = Asset(**meta.model_dump())
    db.add(a)
    db.commit()
    return {"created": True}

@router.get("/metadata")
def get_metadata(key: str, db: Session = Depends(db_dep)):
    a = db.query(Asset).filter(Asset.key == key).one_or_none()
    if not a:
        raise HTTPException(404, "asset not found")
    return {
        "key": a.key,
        "content_type": a.content_type,
        "bytes": a.bytes,
        "bbox": [a.bbox_minx,a.bbox_miny,a.bbox_minz,a.bbox_maxx,a.bbox_maxy,a.bbox_maxz],
        "draco_compressed": a.draco_compressed,
        "created_at": a.created_at,
    }
