import math
from fastapi import APIRouter, HTTPException, Body, Query, Depends
from pydantic import BaseModel
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import text
from ..deps import db_dep
from ..storage import presign_download
from ..config import settings
import json

router = APIRouter(prefix="/tilesets", tags=["tilesets"])

class RegisterBody(BaseModel):
    name: str
    storage_prefix: str
    tiles: List[str]  # relative paths within the prefix, e.g., tile_x0_y0.pnts

@router.post("/register")
def register_tileset(b: RegisterBody, db: Session = Depends(db_dep)):
    # Build a canonical tileset.json with relative URIs and a flat children list
    # Query optional global bounds if available later; for now we compute bounding boxes lazily client-side.
    # We'll store minimal root; Vision client will rely on child bounding boxes if needed.
    children = [{"content":{"uri": t}} for t in b.tiles]
    tileset = {
        "asset": {"version":"1.0","tilesetVersion":"pnts-grid"},
        "geometricError": 1000,
        "root": {"boundingVolume":{"region":[-math.pi, -math.pi/2, math.pi, math.pi/2, 0, 1000]}, "geometricError": 0, "refine":"ADD", "children": children}
    }
    # Persist
    up = text("INSERT INTO tilesets(name, root_json, storage_prefix) VALUES (:n, :j::jsonb, :p) ON CONFLICT (name) DO UPDATE SET root_json = :j::jsonb, storage_prefix=:p")
    db.execute(up, {"n": b.name, "j": json.dumps(tileset), "p": b.storage_prefix.strip("/")})
    db.commit()
    return {"ok": True, "tiles": len(b.tiles)}

@router.get("/{name}")
def get_tileset(name: str, db: Session = Depends(db_dep)):
    row = db.execute(text("SELECT root_json, storage_prefix FROM tilesets WHERE name = :n"), {"n": name}).first()
    if not row:
        raise HTTPException(404, "tileset not found")
    tileset = dict(row.root_json)
    prefix = row.storage_prefix.strip("/")
    # Replace each content.uri with a signed URL
    def map_node(node: Dict[str, Any]):
        if "content" in node and "uri" in node["content"]:
            rel = node["content"]["uri"]
            key = f"{prefix}/{rel}"
            node["content"]["uri"] = presign_download(key)
        for ch in node.get("children", []):
            map_node(ch)
    map_node(tileset["root"])
    return tileset
