import json
from fastapi import APIRouter, HTTPException, Query, Depends
from pydantic import BaseModel
from typing import List
from sqlalchemy.orm import Session
from sqlalchemy import text
from ..deps import db_dep

router = APIRouter(prefix="/sensors", tags=["sensors"])

class SensorPoint(BaseModel):
    device: str
    measurements: dict
    timestamp_ms: int

@router.post("/ingest")
def ingest(points: List[SensorPoint], db: Session = Depends(db_dep)):
    if not points:
        raise HTTPException(400, "empty payload")
    # Insert in batches
    sql = text("INSERT INTO sensors(device, ts, measurements) VALUES (:device, to_timestamp(:ts_ms/1000.0), :meas::jsonb) ON CONFLICT DO NOTHING")
    for p in points:
        db.execute(sql, {"device": p.device, "ts_ms": p.timestamp_ms, "meas": json.dumps(p.measurements)})
    db.commit()
    return {"ok": True, "ingested": len(points)}

@router.get("/query")
def query(device: str, start_ms: int, end_ms: int, db: Session = Depends(db_dep)):
    sql = text("""
        SELECT extract(epoch from ts)*1000 as ts_ms, measurements
        FROM sensors
        WHERE device = :device AND ts BETWEEN to_timestamp(:s/1000.0) AND to_timestamp(:e/1000.0)
        ORDER BY ts
    """)
    rows = db.execute(sql, {"device": device, "s": start_ms, "e": end_ms}).all()
    return {"device": device, "rows": [{"ts_ms": r.ts_ms, "measurements": r.measurements} for r in rows]}
